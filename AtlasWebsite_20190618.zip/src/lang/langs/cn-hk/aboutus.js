export default {
  line1: {
    fieldName: "姓名",
    placeholder: "請輸入你的姓名"
  },
  line2: {
    fieldName: "電郵",
    placeholder: "請輸入你的電郵"
  },
  line3: {
    fieldName: "主旨",
    placeholder: "請輸入主旨"
  },
  line4: {
    placeholder: "請輸入詳細內容"
  },
  line5: ["電郵", "電話", "提交"]
};
