export default {
  navList: [
    {
      text: "Home",
      route: "/home"
    },
    {
      text: "Features",
      route: "/features"
    },
    {
      text: "Technology",
      route: "/technology"
    },
    {
      text: "Gallery",
      route: "/gallery"
    },
    {
      text: "Publications",
      route: "/publications"
    },
    {
      text: "Contact Us",
      route: "/contactus"
    }
  ],
  teachLogin: "Teacher Login"
};
