export default {
  line1: {
    fieldName: "Name",
    placeholder: "Please input your name"
  },
  line2: {
    fieldName: "E-mail",
    placeholder: "Please input your email address"
  },
  line3: {
    fieldName: "Subject",
    placeholder: "Please input your subject"
  },
  line4: {
    placeholder: "Please input more detail"
  },
  line5: ["E-mali", "Tel", "Submit"]
};
