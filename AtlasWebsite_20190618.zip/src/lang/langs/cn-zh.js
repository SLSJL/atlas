// cn-zh.js

import nav from "./cn-zh/nav";
import home from "./cn-zh/home";
import feature from "./cn-zh/feature";
import technology from "./cn-zh/technology";
import aboutus from "./cn-zh/aboutus";

export default { nav, home, feature, technology, aboutus };
