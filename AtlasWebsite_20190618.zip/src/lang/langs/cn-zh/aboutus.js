export default {
  line1: {
    fieldName: "姓名",
    placeholder: "请输入你的姓名"
  },
  line2: {
    fieldName: "电邮",
    placeholder: "请输入你的电邮"
  },
  line3: {
    fieldName: "主题",
    placeholder: "请输入主题"
  },
  line4: {
    placeholder: "请输入详细内容"
  },
  line5: ["电邮", "电话", "提交"]
};
