// cn.js

import nav from "./cn-hk/nav";
import home from "./cn-hk/home";
import feature from "./cn-hk/feature";
import technology from "./cn-hk/technology";
import aboutus from "./cn-hk/aboutus";

export default { nav, home, feature, technology, aboutus };
