// en.js

import nav from "./en/nav";
import home from "./en/home";
import feature from "./en/feature";
import technology from "./en/technology";
import aboutus from "./en/aboutus";

export default { nav, home, feature, technology, aboutus };
