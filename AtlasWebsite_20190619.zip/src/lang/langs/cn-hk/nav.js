export default {
  navList: [
    {
      text: "主頁",
      route: "/home"
    },
    {
      text: "功能",
      route: "/features"
    },
    {
      text: "技術",
      route: "/technology"
    },
    {
      text: "相冊",
      route: "/gallery"
    },
    {
      text: "刊物",
      route: "/publications"
    },
    {
      text: "聯絡我們",
      route: "/contactus"
    }
  ],

  teachLogin: "教師登入"
};
